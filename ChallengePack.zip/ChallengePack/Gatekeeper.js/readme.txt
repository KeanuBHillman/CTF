Title: Gatekeeper.js
Points: 3
Flag: CTF_I_DONT_NEED_A_PASSCODE_098753

Direct user to 103.249.238.54:8080
