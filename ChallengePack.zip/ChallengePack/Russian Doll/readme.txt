title: russian doll
points: 4
flag: CTF_ZIP_FILES_813

give user img
