title: digital abyss
points: 10
flag: CTF_I_GUESS_IT_WASNT_SO_BAD_:)

give user file
