Name: Spin the Wheel
points: 3
Flag: CTF_PLEASE_NO_PIRATES_818

Give user only this txt or txt file doesnt matter:
r%u0!{tp$t0}~0!x#p%t$0g`g
