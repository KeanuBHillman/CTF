Title: Pixel Dust
Points: 3
Flag: CTF_BinaryCats_2025

1.png
