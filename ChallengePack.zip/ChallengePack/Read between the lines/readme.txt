title: read between the lines
points: 5
flag: ctf_nighttime_59

Give user txt file or txt and hint seperately. Copy and paste exactly if you edit all formatting as is is required
