Title: House Rules
Points: 1
Flag: CTF_NO_CATS_TO_BE_SCANNED

Direct user to 103.249.238.54:8081
