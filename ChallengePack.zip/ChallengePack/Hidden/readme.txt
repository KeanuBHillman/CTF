title: hidden
points: 4
flag: CTF_I_AM_HIDING_HERE_91

give user img1.png
please dont strip metadata
