Title: Fortune Cookie
Points: 3
Flag: CTF_COOKIE_MONSTER_112

Direct user to 103.249.238.54:3000
