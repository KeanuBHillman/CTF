title: double espresso
points: 5
flag: CTF_IM_SORRY_ABOUT_THIS_CHALLENGE

text:

2DcFp8eKi9GuJTqvWihjQYJr3XJuDd9nwGrTYXiwzjz229BRXvzhsQGiQHWVD3
