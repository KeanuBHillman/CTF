Title: Lost in the Bits
Points: 3
Flag: CTF_ARE_YOU_MEANT_TO_BE_HERE?

Give user file
