title: crossed wires
points: 4
flag: CTF_DINOSAURDINOSAURDINOSAUR

Give user hello.txt
or give user the text and hint individually
